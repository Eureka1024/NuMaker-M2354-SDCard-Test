# NEWLIB (GCC) porting for RT-Thread

Please define RT_USING_LIBC and compile RT-Thread with GCC compiler.



## More Information

https://sourceware.org/newlib/libc.html#Reentrancy

